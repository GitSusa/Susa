<?php
/**
 * The Template for displaying all single portfolio items.
 *
 * @package ringo_mijingo
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<header class="entry-header">
					<h1 class="entry-title"><?php the_title(); ?></h1>			
				</header><!-- .entry-header -->
			
				<div class="entry-content">
					<?php the_post_thumbnail('portfolio-full'); ?>
					<h3 class="portfolio-link"><a href="<?php echo get_post_meta($post->ID, 'URL', true); ?>"><?php echo get_post_meta($post->ID, 'URL', true); ?></a></h3>
					<?php the_content(); ?>
					<?php
						wp_link_pages( array(
							'before' => '<div class="page-links">' . 'Pages:',
							'after'  => '</div>',
						) );
					?>
				</div><!-- .entry-content -->
			</article><!-- #post-## -->


			<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="post-navigation">
				<div class="nav-previous"><?php previous_post_link(); ?></div>
				<div class="nav-next"><?php next_post_link(); ?></div>
			</nav>

			<?php
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() )
					comments_template();
			?>

		<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>