<?php
 /*
 Template Name: Home
 *
 * @package ringo_mijingo
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<!-- No title for the home page -->
					<div class="entry-content">
						<?php the_content(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-## -->

			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->

	<div id="secondary" class="home-portfolio" role="complementary">
		<?php $recent = new WP_Query( array(
				'post_type' => 'portfolio',
				'posts_per_page' => 3,
		    ) );
			if ( $recent->have_posts() ) : ?>
			<h2>Recent Projects</h2>
			<ul>
				<?php while ( $recent->have_posts() ) : $recent->the_post(); ?>
					<li>
						<a href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail('portfolio-thumb'); ?>
						</a>
					</li>
				<?php endwhile; ?>
			</ul>
		<?php wp_reset_postdata(); //reset to the default loop
			endif; ?>
	</div><!-- #secondary -->

<?php get_footer(); ?>
