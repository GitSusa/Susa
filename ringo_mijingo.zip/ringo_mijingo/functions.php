<?php
/**
 * ringo_mijingo functions and definitions
 *
 * @package ringo_mijingo
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function ringo_mijingo_setup() {

	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support( 'automatic-feed-links' );

	/**
	 * Enable support for Post Thumbnails on posts and pages
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'portfolio-thumb', 270, 180, true ); // true = cropped
	add_image_size( 'portfolio-full', 600, 400, true ); // true = cropped

	/**
	 * This theme uses wp_nav_menu() in one location.
	 */
	register_nav_menus( array(
		'primary' => 'Primary Menu'
	) );

}
add_action( 'after_setup_theme', 'ringo_mijingo_setup' );

/**
 * Register widgetized area and update sidebar with default widgets
 */
function ringo_mijingo_widgets_init() {
	register_sidebar( array(
		'name'          => 'Sidebar',
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'ringo_mijingo_widgets_init' );

/**
 * Enqueue scripts and styles
 */
function ringo_mijingo_scripts() {
	wp_enqueue_style( 'ringo_mijingo-style', get_stylesheet_uri() );
	wp_enqueue_script( 'jquery' );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ringo_mijingo_scripts' );

function add_custom_post_types() {
	register_post_type( 'portfolio',
		array(
			'labels' => array(
				'name' => 'Portfolio',
				'singular_name' => 'Project',
				'add_new_item' => 'Add Project',
				'edit_item' => 'Edit Project',
				'new_item' => 'New Project',
				'view_item' => 'View Project',
				'search_items' => 'Search Project',
				'not_found' => 'No Projects Found',
				'not_found_in_trash' => 'No Projects Found in Trash'
			),
			'public' => true,
			'publicly_queryable' => true,
			'has_archive' => true,
			'exclude_from_search' => false,
			'supports' => array( 'title','editor','thumbnail','custom-fields' ),
			'rewrite' => array( 'slug' => 'portfolio', 'with_front' => true ),
			'hierarchical' => false,
		)
	);
}
add_action('init', 'add_custom_post_types');

/* 
* This can create a simple taxonomy to categorize portfolio items. It has the name Roles, as it could be used to categorize projects based on your role in them. To 'switch it on' just remove the comments from the add_action line below.
*/

function create_taxonomies() {
	register_taxonomy('role','portfolio',
		array(
		    'hierarchical' => true,
		    'labels' => array(
		      'name' => _x( 'Roles', 'taxonomy general name' ),
		      'singular_name' => _x( 'Role', 'taxonomy singular name' )
		    	),
		    'show_ui' => true,
		    'query_var' => true,
		    'rewrite' => array( 'slug' => 'role' ),
		)
	);
}
//add_action( 'init', 'create_taxonomies' );
