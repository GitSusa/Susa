<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package ringo_mijingo
 */

get_header(); ?>

	<section id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title">Search Results for: <span>'<?php the_search_query() ?>'</span></h1>
			</header><!-- .page-header -->

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header">
						<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h1>		
						<div class="entry-meta">
							<?php the_date('F j, Y'); ?>
						</div><!-- .entry-meta -->
					</header><!-- .entry-header -->
				
					<div class="entry-summary">
						<?php the_excerpt(); ?>
					</div><!-- .entry-summary -->
				
					<footer class="entry-meta">
						<span class="cat-links">
							Posted in <?php the_category(', '); ?> 
						</span>
			
						<span class="tags-links"> | 
							Tagged: <?php the_tags(', '); ?>
						</span>
				
						<?php if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) : ?>
						<span class="comments-link"> | <?php comments_popup_link( 'Leave a comment', '1 Comment', '% Comments' ); ?></span>
						<?php endif; ?>
					</footer><!-- .entry-meta -->
				</article><!-- #post-## -->


			<?php endwhile; ?>

			<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="paging-navigation">
				<?php if ( get_next_posts_link() ) : ?>
					<div class="nav-previous"><?php next_posts_link( '<span class="meta-nav">&larr;</span> Older posts' ); ?></div>
				<?php endif; ?>
		
				<?php if ( get_previous_posts_link() ) : ?>
					<div class="nav-next"><?php previous_posts_link( 'Newer posts <span class="meta-nav">&rarr;</span>' ); ?></div>
				<?php endif; ?>
			</nav>

		<?php else : ?>
			<div class="page-content">
				<p>No posts found.</p>
			</div>
		<?php endif; ?>

		</div><!-- #content -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>