<?php
/**
 * The template for displaying Archive portfolio pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package ringo_mijingo
 */

get_header(); ?>

	<section id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title">
					Portfolio
				</h1>
			</header><!-- .page-header -->

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail('portfolio-thumb'); ?>
					</a>
				</article><!-- #post-## -->

			<?php endwhile; ?>

			<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="paging-navigation">
				<?php if ( get_next_posts_link() ) : ?>
					<div class="nav-previous"><?php next_posts_link( '<span class="meta-nav">&larr;</span> Older projects' ); ?></div>
				<?php endif; ?>
		
				<?php if ( get_previous_posts_link() ) : ?>
					<div class="nav-next"><?php previous_posts_link( 'Newer projects <span class="meta-nav">&rarr;</span>' ); ?></div>
				<?php endif; ?>
			</nav>

		<?php else : ?>

			<div class="page-content">
				<p>No posts found.</p>
			</div>

		<?php endif; ?>

		</div><!-- #content -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>